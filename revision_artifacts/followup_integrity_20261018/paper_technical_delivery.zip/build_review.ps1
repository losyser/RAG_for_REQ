param([ValidateSet('paper_wiley','response_to_reviewers','mapping_review_supplement')][string]$Target='paper_wiley', [switch]$CheckOnly)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
foreach ($tool in @('pdflatex','bibtex','kpsewhich')) { Get-Command $tool -ErrorAction Stop | Out-Null }
$font = & kpsewhich stix2.sty
if ($LASTEXITCODE -ne 0 -or -not $font) { throw 'Required TeX package stix2-type1 is missing. No font substitution was made.' }
if ($CheckOnly) { Write-Output 'Local compiler and STIX2 dependency checks passed; no build performed.'; exit 0 }
function Invoke-Checked([string]$Tool, [string[]]$Arguments) {
    & $Tool @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Tool failed; stop without replacing any external manuscript." }
}
Invoke-Checked 'pdflatex' @('-interaction=nonstopmode','-halt-on-error',"$Target.tex")
if ($Target -eq 'paper_wiley') { Invoke-Checked 'bibtex' @($Target) }
Invoke-Checked 'pdflatex' @('-interaction=nonstopmode','-halt-on-error',"$Target.tex")
Invoke-Checked 'pdflatex' @('-interaction=nonstopmode','-halt-on-error',"$Target.tex")
