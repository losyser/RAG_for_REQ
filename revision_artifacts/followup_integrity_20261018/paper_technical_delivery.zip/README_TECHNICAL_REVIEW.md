# Independent technical review copy — not an adopted manuscript version

All research text, tables and figure inputs are copied unchanged from the current manuscript directory. No conclusions, numerical results or requirement identifiers were edited. The original directory, desktop and submission-version choice are untouched.

Added `build_review.ps1` provides explicit targets for manuscript, response and mapping supplement, checks compiler/font dependencies before building, checks every process result and writes only in this independent copy. `-CheckOnly` was tested; a new PDF build/visual acceptance was not performed. The checked local STIX2 package exists in TeX Live 2025. The copied Fonts directory alone is not a portable pdfLaTeX font installation: another machine must supply `stix2-type1` and the template's other TeX dependencies. No silent font substitution is used.

`cumulative_source_changes.diff` compares the saved original-submission TeX **with its four saved original table inputs** against the current text with current inputs expanded. This corrects the review boundary for a textual cumulative comparison; it is not a marked PDF or proof of original figure fidelity. `original_submission_flattened_readonly.tex` is a review snapshot, not a restored historical adopted manuscript. Do not use it to overwrite the source directory. Historical `paper_wiley_diff.tex` is copied for provenance and is stale relative to the current text; do not mistake it for the cumulative result.

Source label/ref checks found no duplicate labels or unresolved references in the flattened current manuscript. Existing current build log contains no undefined-reference or missing-character findings in the checked patterns; this is not a new compilation. Numbering was therefore not guessed or changed. Results/citation/figure-content changes need author decisions and are outside this technical copy.

The exact earlier P1–P6 list was not available in the located local reports at creation time; no invented mapping of those identifiers is claimed. Font, baseline, original-input and reference checks are recorded separately in `../PAPER_TECHNICAL_CHECK.json`.
