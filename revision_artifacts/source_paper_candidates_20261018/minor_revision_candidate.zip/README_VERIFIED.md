# Author-review candidate; not adopted or published

Primary candidate: paper_wiley.tex / paper_wiley.pdf. Cumulative markup: paper_cumulative_diff.tex / .pdf, relative to the exact original_submission.zip. The older paper_wiley_diff.tex and *_original* / *_orig* files are retained historical assets, not the current candidate markup.

Build: python regenerate_diff.py; python build_verified.py paper_wiley paper_cumulative_diff supplementary_ea_notes mapping_review_supplement response_to_reviewers. Requires installed TeX Live packages (including STIX2 Type1); fonts/assets are relative, but this is not a bundled TeX distribution.

Supplementary Material S2 is mapping_review_supplement.pdf; Supplementary Figure N1 is supplementary_ea_notes.pdf. S1 taxonomy, S3 correctness and S4 extraction studies are not complete. The two Pending table source files remain for history but are not included in the candidate main paper. All main scientific numbers, scoring definitions, significance values, table source data and original figure assets are preserved.

PAPER_CHANGE_LEDGER.json records proposed wording changes and their basis. Author confirmation is required before scientific adoption. The public releases do not yet provide the revised frozen experiment or human-review supplement; no upload or submission was performed.

The cumulative diff preserves complete original source/figures in original_submission.zip. Tables and figures use whole-float treatment rather than cell-level markup; original reference numbers are explicitly labelled original. Existing template overfull warnings are retained and reported, not described as zero-warning typography.
