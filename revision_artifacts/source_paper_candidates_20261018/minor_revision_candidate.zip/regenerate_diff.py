"""Regenerate markup from audited expanded original and current complete inputs."""
from pathlib import Path
import subprocess
HERE=Path(__file__).resolve().parent
command=['latexdiff','--flatten','--encoding=utf8','--preamble=diff_preamble.tex',
    '--disable-citation-markup','--no-label',
    r'--config=PICTUREENV=(?:picture[\w\d*@]*|tikzpicture[\w\d*@]*|DIFnomarkup|table[\w\d*@]*|figure[\w\d*@]*)',
    'original_expanded_for_diff.tex','paper_wiley.tex']
result=subprocess.run(command,cwd=HERE,capture_output=True)
(HERE/'latexdiff_generation.txt').write_bytes(result.stderr)
if result.returncode:raise SystemExit(result.returncode)
(HERE/'paper_cumulative_diff.tex').write_bytes(result.stdout)
