"""Local build in this package only. Requires installed TeX Live dependencies."""
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
targets=sys.argv[1:] or ['paper_wiley','paper_cumulative_diff']
if any(t not in ('paper_wiley','paper_cumulative_diff','response_to_reviewers','mapping_review_supplement','supplementary_ea_notes') for t in targets):
    raise SystemExit('Unsupported target')
for package in ('stix2.sty','natbib.sty','tikz.sty','tabularx.sty','booktabs.sty'):
    found=subprocess.run(['kpsewhich',package],capture_output=True)
    if found.returncode or not found.stdout.strip():raise SystemExit('Missing installed TeX dependency: '+package)
for target in targets:
    commands=[['pdflatex','-interaction=nonstopmode','-halt-on-error','-recorder',target+'.tex']]
    if target=='paper_wiley':commands.append(['bibtex',target])
    commands += [['pdflatex','-interaction=nonstopmode','-halt-on-error','-recorder',target+'.tex']]*2
    for index,command in enumerate(commands):
        result=subprocess.run(command,cwd=HERE,capture_output=True)
        (HERE/f'{target}_build_{index}.txt').write_bytes(result.stdout+result.stderr)
        print(target,index,result.returncode,flush=True)
        if result.returncode:raise SystemExit(result.returncode)
